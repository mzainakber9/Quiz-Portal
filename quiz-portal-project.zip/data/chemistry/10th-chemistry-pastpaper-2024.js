// Converted from the original chemistry10th-set1.js
QuizBank.register({
  class: "10th",
  subject: "Chemistry",
  type: "pastpaper",
  id: "2024",
  label: "Past Paper 2024",
  order: 1,
  questions: function () {
    return [
    {
  q: "Slag is obtained as impurity in the metallurgical processes. Identify slag from the following:",
  options: ["CuO", "FeSiO3", "Cu2S", "FeO"],
  ans: "FeSiO3",
  reason: "Iron silicate (FeSiO3) is a common slag formed in metallurgy."
},
{
  q: "Predict the unit of Kc for the reaction: N2 + O2 ⇌ 2NO",
  options: ["No units", "mol/dm^3", "dm^3/mol", "mol^2/dm^6"],
  ans: "No units",
  reason: "Moles of products equal reactants, so units cancel."
},
{
  q: "According to Lewis concept which of the following is an electron pair acceptor?",
  options: ["NH3", "H2O", "BF3", "OH-"],
  ans: "BF3",
  reason: "BF3 accepts electron pair → Lewis acid."
},
{
  q: "HCl is an acid. Identify the reason from the following:",
  options: ["Can donate proton (H+)", "Contains OH group", "Can accept proton (H+)", "Can donate an electron pair"],
  ans: "Can donate proton (H+)",
  reason: "Acids donate H+ ions."
},
{
  q: "The pH of 10^-3 M aqueous solution of NaOH is:",
  options: ["9", "11", "3", "2"],
  ans: "11",
  reason: "pOH = 3 → pH = 14 - 3 = 11."
},
{
  q: "Which of the following has general formula R-O-R?",
  options: ["Ester", "Alcohol", "Aldehyde", "Ether"],
  ans: "Ether",
  reason: "Ethers have structure R-O-R."
},
{
  q: "Identify the product: CH2=CH2 + KMnO4 + H2O → ?",
  options: ["Tetra hydroxy ethane", "Oxalic Acid", "Glyoxal", "Ethylene glycol"],
  ans: "Ethylene glycol",
  reason: "Cold KMnO4 forms diol (glycol)."
},
{
  q: "Which of the following is an unsaturated hydrocarbon?",
  options: ["CH4", "C2H6", "C2H4", "C3H8"],
  ans: "C2H4",
  reason: "Double bond → unsaturated hydrocarbon."
},
{
  q: "Peptide linkage is present in:",
  options: ["Glucose", "Vitamins", "Carbohydrates", "Proteins"],
  ans: "Proteins",
  reason: "Proteins contain peptide bonds."
},
{
  q: "Atmosphere is composed of ______ layers.",
  options: ["5", "2", "3", "4"],
  ans: "5",
  reason: "Troposphere, Stratosphere, Mesosphere, Thermosphere, Exosphere."
},
{
  q: "Which of the following is a secondary pollutant?",
  options: ["Ammonia", "Sulfuric acid", "Sulphur dioxide", "Carbon dioxide"],
  ans: "Sulfuric acid",
  reason: "Formed in atmosphere from SO2."
},
{
  q: "Slaked lime is used in Solvay process. What is slaked lime?",
  options: ["Sodium hydroxide", "Calcium phosphate", "Sodium phosphate", "Calcium hydroxide"],
  ans: "Calcium hydroxide",
  reason: "Slaked lime = Ca(OH)2."
},
    {
  q: "________ is one of the petroleum fractions.",
  options: ["Ammonia", "Urea", "Diesel", "Mineral salt"],
  ans: "Diesel"
},
{
  q: "Predict the unit of Kc for the following given reversible reaction: 2SO₂ + O₂ ⇌ 2SO₃",
  options: ["mol/dm³", "dm³/mol", "No units", "mol²/dm⁶"],
  ans: "No units"
},
{
  q: "A solution contains 1.0 × 10⁻⁷ M [OH⁻] concentration. This solution is:",
  options: ["Acidic", "Basic", "Neutral", "Strong Acid"],
  ans: "Neutral"
},
{
  q: "Which of the following is a Lewis Base?",
  options: ["BF₃", "NH₃", "AlCl₃", "H⁺"],
  ans: "NH₃"
},
{
  q: "One molecule of H₂O produces one H⁺ ion and one OH⁻ on dissociation. Pick the correct option.",
  options: ["Ionization", "Neutralization", "Self-ionization", "Hydrolysis"],
  ans: "Self-ionization"
},
{
  q: "Unsaturated Hydrocarbons undergo Bromination. Which of the following will undergo bromine water test?",
  options: ["Methane", "Ethene", "Ethane", "Propane"],
  ans: "Ethene"
},
{
  q: "Dehydrohalogenation means the removal of:",
  options: ["Oxygen", "Hydrogen and Halogen", "Hydrogen and Carbon", "Water"],
  ans: "Hydrogen and Halogen"
},
{
  q: "________ is used as a catalyst added to prepare propane according to the following equation: CH₃-CH=CH₂ + H₂ → CH₃-CH₂-CH₃",
  options: ["Iron", "Nickel", "Copper", "Zinc"],
  ans: "Nickel"
},
{
  q: "Glucose is a Carbohydrate (C₆H₁₂O₆). Identify glucose from the following:",
  options: ["Aldose", "Tetrose", "Disaccharide", "Hexose"],
  ans: "Hexose"
},
{
  q: "Lowest temperature in stratosphere is:",
  options: ["-56°C", "-20°C", "0°C", "15°C"],
  ans: "-56°C"
},
{
  q: "Which of the following is a reddish brown gas?",
  options: ["O₂", "NO₂", "CO₂", "NH₃"],
  ans: "NO₂"
},
{
  q: "________ is the formula of urea.",
  options: ["CO(NH₂)₂", "NH₄OH", "Na₂CO₃", "CaCO₃"],
  ans: "CO(NH₂)₂"
},
  {
  q: "The lowest temperature in stratosphere is:",
  options: ["5°C", "55°C", "-5°C", "-55°C"],
  ans: "-55°C"
},
{
  q: "Which of the following gases is used to destroy harmful bacteria in water?",
  options: ["Bromine", "Chlorine", "Iodine", "Fluorine"],
  ans: "Chlorine"
},
{
  q: "Which of the following organic compounds is found in gasoline (Petrol)?",
  options: ["CH₄", "C₁₂H₂₆", "C₈H₁₈", "C₂₀H₄₂"],
  ans: "C₈H₁₈"
},
{
  q: "Predict the unit of Kc for the following reversible reaction: N₂O₄(g) ⇌ 2NO₂(g)",
  options: ["mol dm⁻³", "mol⁻¹ dm³", "mol dm³", "mol⁻¹ dm⁻³"],
  ans: "mol dm⁻³"
},
{
  q: "A reaction in which products react together to reform the original reactants is called:",
  options: ["Exothermic reaction", "Reversible reaction", "Irreversible reaction", "Endothermic reaction"],
  ans: "Reversible reaction"
},
{
  q: "In an aqueous solution of hydrochloric acid the concentration of H⁺ ion is 1 × 10⁻³ mol dm⁻³. This solution is:",
  options: ["Basic", "Neutral", "Amphoteric", "Acidic"],
  ans: "Acidic"
},
{
  q: "In a homologous series, two adjacent compounds differ by:",
  options: ["-CH₂- group", "CH₃ group", "-CH₃ group", "CH₂ group"],
  ans: "-CH₂- group"
},
{
  q: "IUPAC name of C₈H₁₈ is:",
  options: ["Octanal", "Octyne", "Octene", "Octane"],
  ans: "Octane"
},
{
  q: "Which of the following is an aldehyde?",
  options: ["CH₃OCH₃", "CH₃COOH", "CH₃-CHO", "CH₃CH₂OH"],
  ans: "CH₃-CHO"
},
{
  q: "In organic chemistry the term dehydrohalogenation means:",
  options: ["Removal of hydrogen and halogen", "Removal of water and halogen", "Removal of halogen only", "Removal of water only"],
  ans: "Removal of hydrogen and halogen"
},
{
  q: "Identify the monosaccharide from the following carbohydrates:",
  options: ["Sucrose", "Lactose", "Maltose", "Glucose"],
  ans: "Glucose"
},
{
  q: "1 Kilogram of water will occupy minimum space at:",
  options: ["100°C", "-4°C", "4°C", "0°C"],
  ans: "4°C"
},

{
  q: "Which of the following water borne diseases causes acute liver inflammation?",
  options: ["Hepatitis", "Cholera", "Typhoid", "Dysentery"],
  ans: "Hepatitis"
},
{
  q: "Chemical formula of urea is:",
  options: ["NaNO₃", "NH₂CONH₂", "(NH₄)₂SO₄", "NH₂COONH₄"],
  ans: "NH₂CONH₂"
},
{
  q: "Predict the unit of Kc for the following reversible reaction: 2CO(g) + O₂(g) ⇌ 2CO₂(g)",
  options: ["mol² dm⁻⁶", "mol⁻¹ dm³", "mol dm⁻³", "mol⁻¹ dm⁻³"],
  ans: "No units"
},
{
  q: "A state of chemical reaction in which forward and reverse reactions take place at the same rate is called:",
  options: ["Chemical equilibrium", "Equilibrium constant", "Forward reaction", "Reverse reaction"],
  ans: "Chemical equilibrium"
},
{
  q: "Given Kw = [H⁺][OH⁻] = 1 × 10⁻¹⁴ at 25°C. What is the concentration of H⁺ in pure water at 25°C?",
  options: ["1 × 10⁻¹⁴ mol dm⁻³", "1 × 10⁻⁷ mol dm⁻³", "1 × 10⁻¹ mol dm⁻³", "1 × 10⁻⁸ mol dm⁻³"],
  ans: "1 × 10⁻⁷ mol dm⁻³"
},
{
  q: "Organic compounds are non-polar in nature and are NOT soluble in:",
  options: ["Benzene", "Ethanol", "Ether", "Water"],
  ans: "Water"
},
{
  q: "IUPAC name of C₆H₁₄ is:",
  options: ["Hexyne", "Hexanol", "Hexane", "Hexene"],
  ans: "Hexane"
},
{
  q: "Which of the following is an alcohol?",
  options: ["CH₃COCH₃", "CH₃OH", "CH₃OCH₃", "CH₃COOH"],
  ans: "CH₃OH"
},
{
  q: "In organic chemistry the term dehydration means:",
  options: ["Removal of water", "Removal of oxygen", "Removal of hydrogen", "Removal of halogen"],
  ans: "Removal of water"
},
{
  q: "Identify the disaccharide from the following carbohydrates:",
  options: ["Galactose", "Fructose", "Sucrose", "Glucose"],
  ans: "Sucrose"
},
{
  q: "1 Kilogram of water will occupy minimum space at:",
  options: ["-4°C", "4°C", "0°C", "100°C"],
  ans: "4°C"
},
{
  q: "As altitude increases in the troposphere the temperature decreases from 17°C to about:",
  options: ["5°C", "55°C", "-5°C", "-55°C"],
  ans: "-55°C"
}
    ];
  }
});
